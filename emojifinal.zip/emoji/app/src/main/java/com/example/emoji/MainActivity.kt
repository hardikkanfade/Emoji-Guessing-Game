package com.example.emoji

import android.os.Bundle
import android.os.CountDownTimer
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.max
import kotlin.math.min

class MainActivity : AppCompatActivity() {
    private lateinit var emojiText: TextView
    private lateinit var inputAnswer: EditText
    private lateinit var feedbackText: TextView
    private lateinit var scoreText: TextView
    private lateinit var timerText: TextView
    private lateinit var hintButton: Button
    private lateinit var submitButton: Button

    private var selectedCategory: String = ""
    private var emojiItems: List<Pair<String, String>> = listOf()
    private var currentEmojiIndex = 0
    private var score = 0
    private var level = 1
    private var timer: CountDownTimer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        emojiText = findViewById(R.id.emojiText)
        inputAnswer = findViewById(R.id.inputAnswer)
        feedbackText = findViewById(R.id.feedbackText)
        scoreText = findViewById(R.id.scoreText)
        timerText = findViewById(R.id.timerText)
        hintButton = findViewById(R.id.hintButton)
        submitButton = findViewById(R.id.submitButton)

        submitButton.setOnClickListener { checkAnswer() }
        hintButton.setOnClickListener { showHint() }

        askUserInterest()
    }

    private fun askUserInterest() {
        val categories = arrayOf("Movies", "Cartoons", "Play Ground games", "Animals")
        AlertDialog.Builder(this)
            .setTitle("Select Your Interest")
            .setItems(categories) { _, which ->
                selectedCategory = categories[which]
                initializeEmojiList(selectedCategory)
                loadNextEmoji()
            }
            .setCancelable(false)
            .show()
    }

    private fun initializeEmojiList(category: String) {
        val emojiData = mapOf(
            "Movies" to listOf(
                "🦁👑" to "Lion King",
                "👟🛏️" to "Sholay",
                "☕🔄🔒" to "Mughal-e-Azam",
                "🅳🅳📜🎭" to "DDLJ",
                "3️⃣🆔🅸🎭" to "3 Idiots",
                "👻🤕🌊🏙️💧" to "Gangs of Wasseypur",
                "💤🚫🎭🏞️" to "ZNMD",
                "📉🎨👦❤️" to "Bajrangi Bhaijaan",
                "🚫🙌🏠🎵" to "Andhadhun",
                "🅿️🔑" to "PK",
                "🩺🔮🍠" to "Drishyam",
                "🎡🎁🇮🇳" to "Chak De! India",
                "🔤🚣💰🔵🚀" to "Taare Zameen Par",
                "👀💁‍♂️🎤🎵🤷‍♂️" to "Koi Mil Gaya",
                "😂🎶" to "Lagaan",
                "😬🚹" to "Jawan",
                "🛤️🔔" to "Pathaan",
                "🍞👩" to "Dangal",
                "🎨🍦🧼1️⃣5️⃣" to "Article 15",
                "🌞🍹" to "Sanju",
                "🦀📌🎤🚶‍♂️" to "Kabir Singh",
                "🐑📍🧔" to "Baahubali",
                "🐑📍🧔2️⃣" to "Baahubali 2",
                "🔄🔄🔄" to "RRR",
                "🤾👴" to "Pushpa",
                "🚀🌙🔴🍷" to "Arjun Reddy",
                "👁️🎻" to "Eega",
                "🚗🌡️🔑🍎2️⃣" to "Karthikeya 2",
                "🎶🎸📦🍵🐱🎶🚽" to "Ala Vaikunthapurramuloo",
                "👗🔄❌🛠️🏠" to "Sarileru Neekevvaru",
                "🌏🐀🚀🤷‍♂️🍜🧍‍♂️" to "Bharat Ane Nenu",
                "💪🎭" to "Mahanati",
                "📜👨🍂🎭" to "Srimanthudu",
                "🏴‍☠️👆☀️👩‍🦳" to "Sita Ramam",
                "🚶‍♂️🌊" to "Jersey",
                "🔍💨⏳" to "Magadheera"
            ),
            "Cartoons" to listOf(
                "🧽⭐" to "SpongeBob",
                "🤏 🐝 Ⓜ️" to "Chhota Bheem",
                "Ⓜ️ ⭕ ✌️ 🅿️🛌🏼" to "Motu Patlu",
                "🚪🙎🏼‍♂️" to "Doraemon (Originally Japanese but extremely popular in India)",
                "✨☕" to "Shinchan (Originally Japanese but loved in India)",
                "🗞️2️⃣1️⃣" to "Roll No. 21",
                "🛌🏼🛌🏼🛌🏼" to "Kumbh Karan",
                "🤏🏼🪈🐄" to "Little Krishna",
                "🙋🏼‍♂️🙅🏼‍♂️🫣" to "Eena Meena Deeka",
                "🐘🤏🏼" to "Bade Chote",
                "👩🏼‍🏫 😥" to "Guru Aur Bhole",
                "🤖👦🏼" to "ViR: The Robot Boy",
                "4️⃣🚓" to "Chorr Police",
                "👖👨🏼‍🦱" to "Pokemon",
                "🐉⚽💤" to "Dragon Ball Z",
                "👶🏼🛌🏼 down" to "Beyblade",
                "🥷🏼🔨" to "Ninja Hattori",
                "/ 👨🏼‍🦱" to "Perman",
                "💪🏼👧🏼" to "The Powerpuff Girls",
                "🚫 body" to "Noddy",
                "og 🪳" to "Oggy and the Cockroaches",
                "mr. 🫘" to "Mr. Bean (Animated)",
                "🚌 🚆" to "Ben 10"
            ),
            "playground" to listOf(
                "🏃‍♂️🔄" to "Kho-Kho",
                "🤼‍♂️💨" to "Kabaddi",
                "🏏🎯" to "Gilli Danda",
                "🪨⚡" to "Pitthu (Lagori)",
                "🟢⚫" to "Kancha (Marbles)",
                "🦶🔢" to "Stapoo (Hopscotch)",
                "➡️⬆️⬇️" to "Kith-Kith",
                "🏃‍♂️🏃‍♀️💨" to "Pakdam Pakdai (Tag)",
                "🦵🚶‍♂️" to "Langdi",
                "🌀🪀" to "Lattu (Spinning Top)",
                "🔗🏃‍♂️🏃‍♀️" to "Sakhli (Chain Game)",
                "⚠️🙅‍♂️🏃‍♀️" to "Vish-Amrit",
                "🦴🐕" to "Dog and the Bone",
                "🏃‍♂️🧣🏃‍♀️" to "Rumaal Chor (Stealing the Handkerchief)",
                "📦🏃‍♂️" to "Dabba Express (Run & Hide)",
                "🚔🕵️‍♂️" to "Chor-Sipahi (Thief & Police)",
                "⬆️⬇️🏃‍♀️" to "Oonch Neech (High & Low)",
                "🙈🔍" to "Chupan Chupai (Hide & Seek)",
                "🌉🤲" to "Poshampa (Bridge Game)",
                "⛓️🏃" to "Chain Chain",
                "🔲🏃‍♂️" to "Four Corners",
                "🏃‍♂️🎒" to "Sack Race",
                "🍋🥄🏃‍♂️" to "Lemon and Spoon Race",
                "🏃‍♂️🦵🦵" to "Three-Legged Race",
                "🤼‍♂️🪢" to "Tug of War",
                "🏀🪣" to "Ball in the Bucket",
                "🏐💨" to "Dodgeball",
                "7️⃣🪨" to "Seven Tiles (Satolia)",
                "🐵🎾" to "Monkey in the Middle",
                "🏗️🪨🏃‍♂️" to "Pittu Garam",
                "🤾‍♀️🔄" to "Rassi Koodna (Skipping Rope)",
                "🤸‍♂️🎵" to "Jumping Jacks",
                "🎟️🔢" to "Housie (Tambola)",
                "🏃‍♂️🔄🍳" to "Catching Cook",
                "🎶🪑" to "Musical Chairs",
                "🦆🦆🦢" to "Duck Duck Goose",
                "🤕🔗" to "Blindfold Catch (Andha Pati)",
                "🎒💨" to "Sack Thief",
                "🤾‍♀️🏐" to "Throw Ball",
                "👏🎶" to "Clap Game (Pat-a-Cake)"
            ),
            "Animals" to listOf(
                "🐘🌿" to "Elephant",
                "🦁🔥" to "Lion",
                "🐯🌳" to "Tiger",
                "🐻🍯" to "Bear",
                "🐺🌙" to "Wolf",
                "🦊🍂" to "Fox",
                "🐶🦴" to "Dog",
                "🐱🐟" to "Cat",
                "🐭🧀" to "Mouse",
                "🐹🥜" to "Hamster",
                "🐰🥕" to "Rabbit",
                "🦔🍂" to "Hedgehog",
                "🦇🌌" to "Bat",
                "🐢🌿" to "Turtle",
                "🐍🌿" to "Snake",
                "🦎☀️" to "Lizard",
                "🦖🌋" to "T-Rex",
                "🦕🌿" to "Brachiosaurus",
                "🐉🔥" to "Dragon",
                "🦅🌄" to "Eagle",
                "🦜🌴" to "Parrot",
                "🦆💦" to "Duck",
                "🦢🌊" to "Swan",
                "🦉🌙" to "Owl",
                "🐔🥚" to "Chicken",
                "🐧❄️" to "Penguin",
                "🐦🎶" to "Bird",
                "🦩🌺" to "Flamingo",
                "🦚✨" to "Peacock",
                "🦒🌿" to "Giraffe",
                "🦓🌾" to "Zebra",
                "🦬🌿" to "Bison",
                "🐄🥛" to "Cow",
                "🐖🐷" to "Pig",
                "🐑🌾" to "Sheep",
                "🐐⛰️" to "Goat",
                "🐎🏇" to "Horse",
                "🦘🌏" to "Kangaroo",
                "🦥🌳" to "Sloth",
                "🦨💨" to "Skunk"
            )
        )
        emojiItems = emojiData[category] ?: emptyList()
        if (emojiItems.isEmpty()) {
            Toast.makeText(this, "No emojis available for this category!", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    private fun loadNextEmoji() {
        if (currentEmojiIndex >= emojiItems.size) {
            levelUp()
            return
        }

        val (emoji, _) = emojiItems[currentEmojiIndex]
        emojiText.text = emoji
        inputAnswer.text.clear()
        feedbackText.text = ""
        startTimer()
    }

    private fun startTimer() {
        timer?.cancel()
        val timeLimit = 60000L // 60 seconds

        timer = object : CountDownTimer(timeLimit, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                timerText.text = "Time: ${millisUntilFinished / 1000}s"
            }

            override fun onFinish() {
                feedbackText.text = "Time's up!"
                currentEmojiIndex++
                loadNextEmoji()
            }
        }.start()
    }

    private fun checkAnswer() {
        timer?.cancel()
        val userAnswer = inputAnswer.text.toString().trim().lowercase()
        val correctAnswer = emojiItems[currentEmojiIndex].second.lowercase()

        if (isSimilar(userAnswer, correctAnswer)) {
            score += 10
            feedbackText.text = "Correct!"
        } else {
            feedbackText.text = "Wrong! The answer was $correctAnswer"
        }

        scoreText.text = "Score: $score"
        currentEmojiIndex++
        loadNextEmoji()
    }

    private fun isSimilar(input: String, answer: String): Boolean {
        val distance = levenshteinDistance(input, answer)
        val threshold = max(1, answer.length / 5) // Allow minor mistakes
        return distance <= threshold
    }

    private fun levenshteinDistance(s1: String, s2: String): Int {
        val dp = Array(s1.length + 1) { IntArray(s2.length + 1) }
        for (i in s1.indices) dp[i + 1][0] = i + 1
        for (j in s2.indices) dp[0][j + 1] = j + 1
        for (i in s1.indices) {
            for (j in s2.indices) {
                val cost = if (s1[i] == s2[j]) 0 else 1
                dp[i + 1][j + 1] = min(
                    min(dp[i][j + 1] + 1, dp[i + 1][j] + 1),
                    dp[i][j] + cost
                )
            }
        }
        return dp[s1.length][s2.length]
    }

    private fun showHint() {
        val correctAnswer = emojiItems[currentEmojiIndex].second

        val hints = mapOf(
            // Movies
            "Lion King" to "Rhymes with 'Zion Ring'—a jungle prince’s journey!",
            "Sholay" to "A legendary Bollywood action film with two heroes!",
            "Mughal-e-Azam" to "A grand love story from the Mughal era!",
            "DDLJ" to "A classic love story where 'palat' became iconic!",
            "3 Idiots" to "A movie about college life, rhymes with 'three wits'!",
            "Gangs of Wasseypur" to "A crime saga with coal mines and revenge!",
            "ZNMD" to "A film about three friends on a road trip in Spain!",
            "Bajrangi Bhaijaan" to "A man helps a lost girl return to her country!",
            "Andhadhun" to "A blind pianist caught in a crime thriller!",
            "PK" to "An alien questions human beliefs on Earth!",
            "Drishyam" to "A man uses movies to cover up a crime!",
            "Chak De! India" to "A hockey team fights for their country's pride!",
            "Taare Zameen Par" to "A heartfelt story about a child and his teacher!",
            "Koi Mil Gaya" to "An alien befriends a special boy!",
            "Lagaan" to "Cricket is the key to winning against the British!",
            "Jawan" to "A soldier fights for justice—think 'young' in Hindi!",
            "Pathaan" to "An action-packed film starring King Khan!",
            "Dangal" to "A father trains his daughters in wrestling!",
            "Article 15" to "A cop investigates caste-based injustice!",
            "Sanju" to "A biopic of a famous Bollywood actor’s ups and downs!",
            "Kabir Singh" to "A rebellious doctor deals with heartbreak!",
            "Baahubali" to "A mighty warrior fights for his kingdom!",
            "Baahubali 2" to "The sequel reveals 'why Kattappa killed him'!",
            "RRR" to "A high-energy movie with revolutionaries!",
            "Pushpa" to "A sandalwood smuggler’s rise—'Thaggede Le'!",
            "Arjun Reddy" to "A hot-headed doctor’s love story, remade as Kabir Singh!",
            "Eega" to "A man reincarnates as a fly for revenge!",
            "Karthikeya 2" to "A mystery involving Lord Krishna’s secrets!",
            "Ala Vaikunthapurramuloo" to "A stylish film with the hit song 'Butta Bomma'!",
            "Sarileru Neekevvaru" to "A soldier’s patriotic mission!",
            "Bharat Ane Nenu" to "A young man becomes the chief minister!",
            "Mahanati" to "A biopic of a legendary actress!",
            "Srimanthudu" to "A rich man adopts a village!",
            "Sita Ramam" to "A love story unfolds through letters!",
            "Jersey" to "A cricketer makes a comeback for his son!",
            "Magadheera" to "A reincarnation saga with epic battles!",

            // Cartoons
            "SpongeBob" to "Lives in a pineapple under the sea!",
            "Chhota Bheem" to "A little hero who loves laddoos!",
            "Motu Patlu" to "One loves samosas, the other is his buddy!",
            "Doraemon" to "A robotic cat with a magical pocket!",
            "Shinchan" to "A naughty kid famous for his mischief!",
            "Roll No. 21" to "Krishna fights Kansa in modern times!",
            "Kumbh Karan" to "Two brothers—one always sleeping!",
            "Little Krishna" to "A divine blue boy loves butter!",
            "Eena Meena Deeka" to "Three birds always outsmart a fox!",
            "Bade Chote" to "A big and small duo solving mysteries!",
            "Guru Aur Bhole" to "A music-loving duo and their adventures!",
            "ViR: The Robot Boy" to "A boy with AI-powered super abilities!",
            "Chorr Police" to "A cop always chasing a clever thief!",
            "Pokemon" to "A world of catching creatures—'Pikachu'!",
            "Dragon Ball Z" to "A warrior unlocks his Super Saiyan power!",
            "Beyblade" to "Let it rip! Spinning battles begin!",
            "Ninja Hattori" to "A little ninja helps his human friend!",
            "Perman" to "A boy with a mask and superhero cape!",
            "The Powerpuff Girls" to "Three super girls made with sugar, spice, and everything nice!",
            "Noddy" to "A little toy car driver in Toyland!",
            "Oggy and the Cockroaches" to "A blue cat always annoyed by three bugs!",
            "Mr. Bean (Animated)" to "A silly man and his teddy!",
            "Ben 10" to "A boy with a watch that transforms him!",

            // Playground Games
            "Kho-Kho" to "A running game where you touch and chase!",
            "Kabaddi" to "Hold your breath and tag players before returning!",
            "Gilli Danda" to "Hit the small stick into the air with a big stick!",
            "Pitthu (Lagori)" to "Hit and rebuild the tower of stones!",
            "Kancha (Marbles)" to "Shoot and collect glass balls!",
            "Stapoo (Hopscotch)" to "Jump on numbers drawn on the ground!",
            "Kith-Kith" to "Another name for Hopscotch!",
            "Pakdam Pakdai (Tag)" to "A chasing game—you're it!",
            "Langdi" to "Hop on one leg to catch players!",
            "Lattu (Spinning Top)" to "Make a wooden top spin with a string!",
            "Sakhli (Chain Game)" to "Form a chain to catch players!",
            "Vish-Amrit" to "Freeze and unfreeze teammates!",
            "Dog and the Bone" to "Snatch the object before the opponent!",
            "Rumaal Chor (Handkerchief Thief)" to "Run and steal the scarf first!",
            "Dabba Express" to "Knock down the can and run!",
            "Chor-Sipahi (Thief-Police)" to "A classic cops and robbers game!",
            "Oonch Neech (High-Low)" to "Stay on high ground to avoid being caught!",
            "Chupan Chupai (Hide & Seek)" to "Find your hiding friends!",
            "Poshampa" to "Pass through the bridge before it falls!",
            "Chain Chain" to "Catch players to extend the chain!",
            "Four Corners" to "Claim a corner before someone else does!",
            "Sack Race" to "Hop to the finish line in a sack!",
            "Lemon and Spoon Race" to "Balance a lemon while running!",
            "Three-Legged Race" to "Tie your leg with a friend and run!",
            "Tug of War" to "Pull the rope to your side!",
            "Ball in the Bucket" to "Aim and throw the ball inside!",
            "Dodgeball" to "Dodge and throw the ball at others!",
            "Seven Tiles (Satolia)" to "Rebuild a tower after getting hit!",
            "Monkey in the Middle" to "Pass the ball while avoiding the catcher!",
            "Pittu Garam" to "Break and rebuild the stack of stones!",
            "Skipping Rope" to "Jump over a swinging rope!",
            "Jumping Jacks" to "Hop while clapping your hands!",
            "Housie (Tambola)" to "A number-based luck game!",
            "Catching Cook" to "One runs, others chase!",
            "Musical Chairs" to "Walk around, sit when the music stops!",
            "Duck Duck Goose" to "Run fast before you get caught!",
            "Blindfold Catch (Andha Pati)" to "Find players while blindfolded!",
            "Sack Thief" to "Steal the sack and run!",
            "Throw Ball" to "Pass the ball without dropping it!",
            "Clap Game" to "Pat-a-cake, pat-a-cake!",

            // Animals
            "Elephant" to "A giant with a trunk, rhymes with 'relevant'!",
            "Tiger" to "A striped big cat, rhymes with 'fighter'!",
        "Bear" to "Loves honey and naps, rhymes with 'stare'!",
        "Wolf" to "A howling hunter, rhymes with 'gulf'!",
        "Fox" to "Clever and sly, rhymes with 'box'!",
        "Dog" to "Man’s best friend, rhymes with 'fog'!",
        "Cat" to "Purrs a lot and naps on a mat!",
        "Mouse" to "Tiny and quick, rhymes with 'house'!",
        "Hamster" to "Stores food in cheeks, rhymes with 'gamester'!",
        "Rabbit" to "Hops around, rhymes with 'habit'!",
        "Hedgehog" to "Spiky but cute, rhymes with 'log'!",
        "Bat" to "Flies at night, rhymes with 'hat'!",
        "Turtle" to "Slow and steady, rhymes with 'hurdle'!",
        "Snake" to "Slithers around, rhymes with 'lake'!",
        "Lizard" to "Scaly and quick, rhymes with 'wizard'!",
        "T-Rex" to "A dinosaur with short arms, no flex!",
        "Brachiosaurus" to "A giant dino who eats from treetops!",
        "Dragon" to "A mythical beast that breathes fire!",
        "Eagle" to "The king of the sky, rhymes with 'beagle'!",
        "Parrot" to "A talking bird, rhymes with 'carrot'!",
        "Duck" to "Loves the pond, rhymes with 'luck'!",
        "Swan" to "Graceful and white, glides on a lake!",
        "Owl" to "Says 'hoot hoot', rhymes with 'foul'!",
        "Chicken" to "Lays eggs daily, rhymes with 'thicken'!",
        "Penguin" to "A flightless bird in the cold, rhymes with 'begin'!",
        "Bird" to "Has wings and sings, rhymes with 'word'!",
        "Flamingo" to "A pink bird on one leg, rhymes with 'bingo'!",
        "Peacock" to "A bird with a fancy tail, rhymes with 'rock'!",
        "Giraffe" to "Tallest animal, rhymes with 'laugh'!",
        "Zebra" to "Striped like a barcode, rhymes with 'era'!",
        "Bison" to "A shaggy beast, rhymes with 'horizon'!",
        "Cow" to "Gives us milk, rhymes with 'how'!",
        "Pig" to "Loves mud, rhymes with 'big'!",
        "Sheep" to "Fluffy and white, rhymes with 'sleep'!",
        "Goat" to "Climbs mountains, rhymes with 'boat'!",
        "Horse" to "Runs really fast, rhymes with 'course'!",
        "Kangaroo" to "Jumps with a pouch, rhymes with 'boo'!",
        "Sloth" to "Slow and lazy, rhymes with 'both'!",
        "Skunk" to "Sprays a stink, rhymes with 'trunk'!"

        )

        val hint = hints[correctAnswer] ?: "Think carefully! It's a well-known name."

        feedbackText.text = "Hint: $hint"
        score = max(0, score - 2)
        scoreText.text = "Score: $score"
    }


    private fun levelUp() {
        level++
        currentEmojiIndex = 0

        if (level > 3) {
            feedbackText.text = "Game Over! Final Score: $score"
        } else {
            feedbackText.text = "Level $level!"
            loadNextEmoji()
        }
    }
}
